using UnityEngine;

public class BacrkgroundScript : MonoBehaviour
{

    // Update is called once per frame
    void Update()
    {
        transform.position = new Vector3(transform.position.x, 5.59f, 0);
    }
}
